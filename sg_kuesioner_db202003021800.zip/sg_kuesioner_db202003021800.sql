-- MySQL dump 10.15  Distrib 10.0.19-MariaDB, for Win32 (AMD64)
--
-- Host: localhost    Database: sg_kuesioner_db
-- ------------------------------------------------------
-- Server version	10.4.11-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `categories` (
  `CategoryID` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryName` varchar(15) DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `Picture` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`CategoryID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`CategoryID`, `CategoryName`, `Description`, `Picture`) VALUES (1,'Beverages m','Soft drinks, coffees, teas, beers, and ales,Ciu',NULL),(2,'Condiments','Sweet and savory sauces, relishes, spreads, and seasonings',''),(3,'Confections','Desserts, candies, and sweet breads',''),(4,'Dairy Productio','Cheeses',''),(5,'Grains and Cere','Breads, crackers, pasta, and cerealist',''),(6,'Web Dinamis','Siswa El rahma','737Image4484.jpg'),(8,'UnCategory v','No One Category','284Image4476.jpg'),(9,'hvhvh','vhvh gvhvhvh',NULL);

--
-- Table structure for table `dosen`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `dosen` (
  `npp` varchar(30) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`npp`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dosen`
--

INSERT INTO `dosen` (`npp`, `nama`, `created_at`, `updated_at`) VALUES ('18922633','Ana Suryaningsih','2019-12-27 21:43:25','0000-00-00 00:00:00'),('23123122','Muhammad Munir Akromin','0000-00-00 00:00:00','0000-00-00 00:00:00'),('23476236','Linda Pratiwi','2019-12-18 22:01:08','0000-00-00 00:00:00'),('27312371','Zilfana Falahi','2019-12-13 00:00:00','2019-12-14 00:19:03'),('46564136','Intan Hidayah','2019-12-18 22:01:08','0000-00-00 00:00:00'),('64516761','Adi Kurniawan','2019-12-13 00:00:00','0000-00-00 00:00:00'),('64724515','Faiz Ibnu Sholeh','0000-00-00 00:00:00','0000-00-00 00:00:00'),('67423747','Miftakhul Huda','2019-12-27 21:43:25','0000-00-00 00:00:00'),('92632543','Fajar Nopriangga','2019-12-26 23:06:49','2019-12-26 17:10:03');

--
-- Table structure for table `dosen_kelas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `dosen_kelas` (
  `dsnKelasID` varchar(30) NOT NULL,
  `kelasID` varchar(30) NOT NULL,
  `npp` varchar(30) NOT NULL,
  `thnAkademikID` varchar(30) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`dsnKelasID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dosen_kelas`
--

INSERT INTO `dosen_kelas` (`dsnKelasID`, `kelasID`, `npp`, `thnAkademikID`, `created_at`, `updated_at`) VALUES ('200202095905','378457','18922633','544587','2020-02-02 21:59:12','0000-00-00 00:00:00'),('200202095916','378457','46564136','544587','2020-02-02 21:59:25','0000-00-00 00:00:00'),('200202095928','378457','67423747','544587','2020-02-02 21:59:36','0000-00-00 00:00:00'),('200202101741','378457','64724515','213123','2020-02-02 22:17:49','0000-00-00 00:00:00'),('200203035002','341313','92632543','544587','2020-02-03 03:50:14','0000-00-00 00:00:00'),('200301020002','673745','23123122','544587','0000-00-00 00:00:00','0000-00-00 00:00:00'),('425638','341313','64516761','544587','2019-12-16 00:00:00','0000-00-00 00:00:00');

--
-- Table structure for table `group_dosen`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `group_dosen` (
  `groupID` varchar(30) NOT NULL,
  `prodiID` varchar(30) NOT NULL,
  `nama` varchar(300) NOT NULL,
  `jawaban` varchar(100) NOT NULL,
  `nilai` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`groupID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_dosen`
--

INSERT INTO `group_dosen` (`groupID`, `prodiID`, `nama`, `jawaban`, `nilai`, `created_at`, `updated_at`) VALUES ('200202101100','13201','Materi Perkuliahan','Sangat Tidak Setuju, Tidak Setuju, Ragu-ragu, Setuju, Sangat Setuju','1,2,3,4,5','2020-02-02 22:11:49','0000-00-00 00:00:00'),('200202101212','13201','Penyampaian Materi oleh Dosen','Sangat Tidak Setuju, Tidak Setuju, Ragu-ragu, Setuju, Sangat Setuju','1,2,3,4,5','2020-02-02 22:12:40','0000-00-00 00:00:00'),('200202101243','13201','Pengelolaan Kelas','Sangat Tidak Setuju, Tidak Setuju, Ragu-ragu, Setuju, Sangat Setuju','1,2,3,4,5','2020-02-02 22:13:05','0000-00-00 00:00:00'),('200202101314','13201','Evaluasi Pengajaran','Sangat Tidak Setuju, Tidak Setuju, Ragu-ragu, Setuju, Sangat Setuju','1,2,3,4,5','2020-02-02 22:13:31','0000-00-00 00:00:00');

--
-- Table structure for table `group_pertanyaan`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `group_pertanyaan` (
  `groupID` varchar(30) NOT NULL,
  `prodiID` varchar(30) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `jawaban` varchar(300) NOT NULL,
  `nilai` varchar(30) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`groupID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_pertanyaan`
--

INSERT INTO `group_pertanyaan` (`groupID`, `prodiID`, `nama`, `jawaban`, `nilai`, `created_at`, `updated_at`) VALUES ('122222','0','Sarana dan Prasarana','Kurang,Cukup,Baik,Sangat Baik','1, 2, 3, 4, 5','2020-01-01 14:52:50','2020-02-27 06:32:05'),('200226070612','0','Visi Misi Stikes Surya Global','Benar,Salah','1,2','2020-02-26 07:06:59','2020-02-27 06:31:57'),('200226070732','14001','Visi Misi Program Studi Ilmu Keperawatan / Ners','Benar,Salah','1,2','2020-02-26 07:08:37','2020-02-26 07:08:53'),('200227044209','13201','Visi Misi Program Studi Kesehatan Masyarakat','Benar,Salah','1,2','2020-02-27 04:42:46','0000-00-00 00:00:00'),('364353','0','Pelayanan Pendidikan','Kurang,Cukup,Baik,Sangat Baik','1, 2, 3, 4, 5','2020-01-01 21:25:15','2020-02-27 06:31:50'),('367453','0','Proses Skripsi / Tugas Akhir','Kurang,Cukup,Baik,Sangat Baik','1, 2, 3, 4, 5','2020-01-01 21:25:15','2020-02-27 06:31:45');

--
-- Table structure for table `groups`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES (1,'admin','Administrator'),(2,'members','General User');

--
-- Table structure for table `hasil`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `hasil` (
  `hasilID` varchar(30) NOT NULL,
  `pertanyaanID` varchar(30) NOT NULL,
  `nim` varchar(30) NOT NULL,
  `jawaban` varchar(100) NOT NULL,
  `thnAkademikID` varchar(30) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`hasilID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hasil`
--

INSERT INTO `hasil` (`hasilID`, `pertanyaanID`, `nim`, `jawaban`, `thnAkademikID`, `created_at`, `updated_at`) VALUES ('0734560001','200202100303','12171570','Kurang','544587','2020-02-17 07:34:56','0000-00-00 00:00:00'),('0734560002','200202100321','12171570','Kurang','544587','2020-02-17 07:34:56','0000-00-00 00:00:00'),('0734560003','231313','12171570','Kurang','544587','2020-02-17 07:34:56','0000-00-00 00:00:00'),('0734560004','536241','12171570','Kurang','544587','2020-02-17 07:34:56','0000-00-00 00:00:00'),('0734560005','564544','12171570','Kurang','544587','2020-02-17 07:34:56','0000-00-00 00:00:00'),('0734560006','200202100337','12171570','Cukup','544587','2020-02-17 07:34:56','0000-00-00 00:00:00'),('0734560007','200202100359','12171570','Cukup','544587','2020-02-17 07:34:56','0000-00-00 00:00:00'),('0734560008','200202100417','12171570','Cukup','544587','2020-02-17 07:34:56','0000-00-00 00:00:00'),('0734560009','200202100429','12171570','Cukup','544587','2020-02-17 07:34:56','0000-00-00 00:00:00'),('0734560010','200202100445','12171570','Cukup','544587','2020-02-17 07:34:56','0000-00-00 00:00:00'),('0734560011','200202100454','12171570','Baik','544587','2020-02-17 07:34:56','0000-00-00 00:00:00'),('0734560012','200202100505','12171570','Baik','544587','2020-02-17 07:34:56','0000-00-00 00:00:00'),('0734560013','200202100518','12171570','Baik','544587','2020-02-17 07:34:56','0000-00-00 00:00:00'),('0734560014','200202100530','12171570','Baik','544587','2020-02-17 07:34:56','0000-00-00 00:00:00'),('0734560015','200202100540','12171570','Baik','544587','2020-02-17 07:34:56','0000-00-00 00:00:00'),('0734560016','200202100605','12171570','Baik','544587','2020-02-17 07:34:56','0000-00-00 00:00:00'),('0737060001','200202100303','12171570','Sangat Baik','544587','2020-02-17 07:37:06','0000-00-00 00:00:00'),('0737060002','200202100321','12171570','Sangat Baik','544587','2020-02-17 07:37:06','0000-00-00 00:00:00'),('0737060003','231313','12171570','Baik','544587','2020-02-17 07:37:06','0000-00-00 00:00:00'),('0737060004','536241','12171570','Cukup','544587','2020-02-17 07:37:06','0000-00-00 00:00:00'),('0737060005','564544','12171570','Baik','544587','2020-02-17 07:37:06','0000-00-00 00:00:00'),('0737060006','200202100337','12171570','Cukup','544587','2020-02-17 07:37:06','0000-00-00 00:00:00'),('0737060007','200202100359','12171570','Baik','544587','2020-02-17 07:37:06','0000-00-00 00:00:00'),('0737060008','200202100417','12171570','Cukup','544587','2020-02-17 07:37:06','0000-00-00 00:00:00'),('0737060009','200202100429','12171570','Baik','544587','2020-02-17 07:37:06','0000-00-00 00:00:00'),('0737060010','200202100445','12171570','Cukup','544587','2020-02-17 07:37:06','0000-00-00 00:00:00'),('0737060011','200202100454','12171570','Kurang','544587','2020-02-17 07:37:06','0000-00-00 00:00:00'),('0737060012','200202100505','12171570','Baik','544587','2020-02-17 07:37:06','0000-00-00 00:00:00'),('0737060013','200202100518','12171570','Cukup','544587','2020-02-17 07:37:06','0000-00-00 00:00:00'),('0737060014','200202100530','12171570','Baik','544587','2020-02-17 07:37:06','0000-00-00 00:00:00'),('0737060015','200202100540','12171570','Cukup','544587','2020-02-17 07:37:06','0000-00-00 00:00:00'),('0737060016','200202100605','12171570','Baik','544587','2020-02-17 07:37:06','0000-00-00 00:00:00'),('0741220001','200202100303','12171570','Cukup','544587','2020-02-17 07:41:22','0000-00-00 00:00:00'),('0741220002','200202100321','12171570','Cukup','544587','2020-02-17 07:41:22','0000-00-00 00:00:00'),('0741220003','231313','12171570','Baik','544587','2020-02-17 07:41:22','0000-00-00 00:00:00'),('0741220004','536241','12171570','Cukup','544587','2020-02-17 07:41:22','0000-00-00 00:00:00'),('0741220005','564544','12171570','Baik','544587','2020-02-17 07:41:22','0000-00-00 00:00:00'),('0741220006','200202100337','12171570','Cukup','544587','2020-02-17 07:41:22','0000-00-00 00:00:00'),('0741220007','200202100359','12171570','Cukup','544587','2020-02-17 07:41:22','0000-00-00 00:00:00'),('0741220008','200202100417','12171570','Baik','544587','2020-02-17 07:41:22','0000-00-00 00:00:00'),('0741220009','200202100429','12171570','Cukup','544587','2020-02-17 07:41:22','0000-00-00 00:00:00'),('0741220010','200202100445','12171570','Baik','544587','2020-02-17 07:41:22','0000-00-00 00:00:00'),('0741220011','200202100454','12171570','Baik','544587','2020-02-17 07:41:22','0000-00-00 00:00:00'),('0741220012','200202100505','12171570','Cukup','544587','2020-02-17 07:41:22','0000-00-00 00:00:00'),('0741220013','200202100518','12171570','Baik','544587','2020-02-17 07:41:22','0000-00-00 00:00:00'),('0741220014','200202100530','12171570','Baik','544587','2020-02-17 07:41:22','0000-00-00 00:00:00'),('0741220015','200202100540','12171570','Baik','544587','2020-02-17 07:41:22','0000-00-00 00:00:00'),('0741220016','200202100605','12171570','Baik','544587','2020-02-17 07:41:22','0000-00-00 00:00:00'),('1006530001','200202100303','12171570','Kurang','544587','2020-02-02 22:06:53','0000-00-00 00:00:00'),('1006530002','200202100321','12171570','Kurang','544587','2020-02-02 22:06:53','0000-00-00 00:00:00'),('1006530003','231313','12171570','Kurang','544587','2020-02-02 22:06:53','0000-00-00 00:00:00'),('1006530004','536241','12171570','Kurang','544587','2020-02-02 22:06:53','0000-00-00 00:00:00'),('1006530005','564544','12171570','Kurang','544587','2020-02-02 22:06:53','0000-00-00 00:00:00'),('1006530006','200202100337','12171570','Cukup','544587','2020-02-02 22:06:53','0000-00-00 00:00:00'),('1006530007','200202100359','12171570','Cukup','544587','2020-02-02 22:06:53','0000-00-00 00:00:00'),('1006530008','200202100417','12171570','Cukup','544587','2020-02-02 22:06:53','0000-00-00 00:00:00'),('1006530009','200202100429','12171570','Cukup','544587','2020-02-02 22:06:53','0000-00-00 00:00:00'),('1006530010','200202100445','12171570','Cukup','544587','2020-02-02 22:06:53','0000-00-00 00:00:00'),('1006530011','200202100454','12171570','Baik','544587','2020-02-02 22:06:53','0000-00-00 00:00:00'),('1006530012','200202100505','12171570','Baik','544587','2020-02-02 22:06:53','0000-00-00 00:00:00'),('1006530013','200202100518','12171570','Baik','544587','2020-02-02 22:06:53','0000-00-00 00:00:00'),('1006530014','200202100530','12171570','Baik','544587','2020-02-02 22:06:53','0000-00-00 00:00:00'),('1006530015','200202100540','12171570','Baik','544587','2020-02-02 22:06:53','0000-00-00 00:00:00'),('1006530016','200202100605','12171570','Baik','544587','2020-02-02 22:06:53','0000-00-00 00:00:00');

--
-- Table structure for table `hasil_dosen`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `hasil_dosen` (
  `hasilID` varchar(30) NOT NULL,
  `pertanyaanID` varchar(30) NOT NULL,
  `nim` varchar(30) NOT NULL,
  `npp` varchar(30) NOT NULL,
  `jawaban` varchar(100) NOT NULL,
  `thnAkademikID` varchar(30) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`hasilID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hasil_dosen`
--

INSERT INTO `hasil_dosen` (`hasilID`, `pertanyaanID`, `nim`, `npp`, `jawaban`, `thnAkademikID`, `created_at`, `updated_at`) VALUES ('0354010001','200202101341','12171566','92632543','5','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010002','200202101400','12171566','92632543','5','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010003','200202101409','12171566','92632543','5','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010004','200202101419','12171566','92632543','5','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010005','200202101428','12171566','92632543','5','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010006','200202101438','12171566','92632543','5','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010007','200202101447','12171566','92632543','5','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010008','200202101457','12171566','92632543','5','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010009','200202101507','12171566','92632543','5','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010010','200202101518','12171566','92632543','5','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010011','200202101538','12171566','92632543','5','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010012','200202101543','12171566','92632543','5','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010013','200202101554','12171566','92632543','5','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010014','200202101603','12171566','92632543','5','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010015','200202101615','12171566','92632543','5','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010016','200202101626','12171566','92632543','5','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010017','200202101635','12171566','92632543','5','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010018','200202101648','12171566','92632543','5','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010019','200202101701','12171566','92632543','5','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010020','200202101341','12171566','64516761','4','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010021','200202101400','12171566','64516761','4','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010022','200202101409','12171566','64516761','4','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010023','200202101419','12171566','64516761','4','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010024','200202101428','12171566','64516761','4','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010025','200202101438','12171566','64516761','4','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010026','200202101447','12171566','64516761','4','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010027','200202101457','12171566','64516761','4','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010028','200202101507','12171566','64516761','4','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010029','200202101518','12171566','64516761','4','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010030','200202101538','12171566','64516761','4','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010031','200202101543','12171566','64516761','4','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010032','200202101554','12171566','64516761','4','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010033','200202101603','12171566','64516761','4','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010034','200202101615','12171566','64516761','4','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010035','200202101626','12171566','64516761','4','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010036','200202101635','12171566','64516761','4','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010037','200202101648','12171566','64516761','4','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('0354010038','200202101701','12171566','64516761','4','544587','2020-02-03 03:54:01','0000-00-00 00:00:00'),('1024110001','200202101341','12171570','18922633','1','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110002','200202101400','12171570','18922633','1','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110003','200202101409','12171570','18922633','1','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110004','200202101419','12171570','18922633','1','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110005','200202101428','12171570','18922633','1','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110006','200202101438','12171570','18922633','1','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110007','200202101447','12171570','18922633','1','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110008','200202101457','12171570','18922633','1','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110009','200202101507','12171570','18922633','1','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110010','200202101518','12171570','18922633','1','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110011','200202101538','12171570','18922633','1','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110012','200202101543','12171570','18922633','1','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110013','200202101554','12171570','18922633','1','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110014','200202101603','12171570','18922633','1','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110015','200202101615','12171570','18922633','1','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110016','200202101626','12171570','18922633','1','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110017','200202101635','12171570','18922633','1','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110018','200202101648','12171570','18922633','1','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110019','200202101701','12171570','18922633','1','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110020','200202101341','12171570','46564136','2','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110021','200202101400','12171570','46564136','2','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110022','200202101409','12171570','46564136','2','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110023','200202101419','12171570','46564136','2','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110024','200202101428','12171570','46564136','2','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110025','200202101438','12171570','46564136','2','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110026','200202101447','12171570','46564136','2','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110027','200202101457','12171570','46564136','2','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110028','200202101507','12171570','46564136','2','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110029','200202101518','12171570','46564136','2','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110030','200202101538','12171570','46564136','2','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110031','200202101543','12171570','46564136','2','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110032','200202101554','12171570','46564136','2','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110033','200202101603','12171570','46564136','2','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110034','200202101615','12171570','46564136','2','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110035','200202101626','12171570','46564136','2','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110036','200202101635','12171570','46564136','2','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110037','200202101648','12171570','46564136','2','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110038','200202101701','12171570','46564136','2','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110039','200202101341','12171570','67423747','3','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110040','200202101400','12171570','67423747','3','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110041','200202101409','12171570','67423747','3','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110042','200202101419','12171570','67423747','3','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110043','200202101428','12171570','67423747','3','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110044','200202101438','12171570','67423747','3','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110045','200202101447','12171570','67423747','3','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110046','200202101457','12171570','67423747','3','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110047','200202101507','12171570','67423747','3','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110048','200202101518','12171570','67423747','3','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110049','200202101538','12171570','67423747','3','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110050','200202101543','12171570','67423747','3','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110051','200202101554','12171570','67423747','3','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110052','200202101603','12171570','67423747','3','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110053','200202101615','12171570','67423747','3','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110054','200202101626','12171570','67423747','3','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110055','200202101635','12171570','67423747','3','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110056','200202101648','12171570','67423747','3','544587','2020-02-02 22:24:11','0000-00-00 00:00:00'),('1024110057','200202101701','12171570','67423747','3','544587','2020-02-02 22:24:11','0000-00-00 00:00:00');

--
-- Table structure for table `kelas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `kelas` (
  `kelasID` varchar(30) NOT NULL,
  `nama_kelas` varchar(150) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`kelasID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`kelasID`, `nama_kelas`, `created_at`, `updated_at`) VALUES ('341313','Kamboja','2019-12-14 06:29:42','2020-02-27 11:00:20'),('345254','Tratai','2019-12-28 10:46:23','0000-00-00 00:00:00'),('378457','Melati','2019-12-14 00:00:00','0000-00-00 00:00:00'),('462464','Tulip','2019-12-28 10:46:23','0000-00-00 00:00:00'),('673745','Mawar','2019-12-14 00:00:00','0000-00-00 00:00:00');

--
-- Table structure for table `login_attempts`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--


--
-- Table structure for table `mahasiswa`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `mahasiswa` (
  `nim` varchar(30) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `prodiID` varchar(150) NOT NULL,
  `angkatan` varchar(30) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`nim`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mahasiswa`
--

INSERT INTO `mahasiswa` (`nim`, `nama`, `prodiID`, `angkatan`, `created_at`, `updated_at`) VALUES ('12171550','Faiz Ibnu Sholeh','14001','2017','2020-02-18 20:08:43','2020-02-18 14:08:55'),('12171552','Diki Kurniawan','13201','2017','2020-02-18 20:31:15','0000-00-00 00:00:00'),('12171563','Miftakhul Huda','13201','2017','2020-02-12 02:57:52','2020-02-12 02:58:06'),('12171564','Ana Suryaningsih','14001','2017','2020-02-18 20:31:15','0000-00-00 00:00:00'),('12171566','Linda Pratiwi','14001','2017','2020-02-02 21:56:13','0000-00-00 00:00:00'),('12171568','Muhammad Alvian Rizky','13201','2017','2019-12-15 00:00:00','2020-01-01 08:54:47'),('12171570','Muhammad Munir Akromin','14901','2017','2020-02-02 21:57:03','0000-00-00 00:00:00');

--
-- Table structure for table `mahasiswa_kelas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `mahasiswa_kelas` (
  `mhsKelasID` varchar(30) NOT NULL,
  `kelasID` varchar(30) NOT NULL,
  `nim` varchar(30) NOT NULL,
  `thnAkademikID` varchar(30) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`mhsKelasID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mahasiswa_kelas`
--

INSERT INTO `mahasiswa_kelas` (`mhsKelasID`, `kelasID`, `nim`, `thnAkademikID`, `created_at`, `updated_at`) VALUES ('200212030811','341313','12171563','213123','2020-02-12 03:08:19','0000-00-00 00:00:00'),('200218100002','673745','12171550','544587','0000-00-00 00:00:00','0000-00-00 00:00:00'),('200218100003','378457','12171552','544587','0000-00-00 00:00:00','0000-00-00 00:00:00'),('200218100004','341313','12171566','544587','0000-00-00 00:00:00','2020-02-18 16:11:59'),('231231','673745','12171568','544587','2019-12-15 00:00:00','2019-12-15 16:32:43'),('651245','378457','12171570','544587','2019-12-15 00:00:00','0000-00-00 00:00:00');

--
-- Table structure for table `pertanyaan`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `pertanyaan` (
  `pertanyaanID` varchar(30) NOT NULL,
  `groupID` varchar(30) NOT NULL,
  `pertanyaan` varchar(300) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`pertanyaanID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pertanyaan`
--

INSERT INTO `pertanyaan` (`pertanyaanID`, `groupID`, `pertanyaan`, `created_at`, `updated_at`) VALUES ('200202100303','122222','Institusi mempunyai perpustakaan yang memadai dengan adanya ruang baca','2020-02-02 22:03:14','0000-00-00 00:00:00'),('200202100321','122222','Institusi menyediakan koleksi buku referensi yang memadai','2020-02-02 22:03:28','0000-00-00 00:00:00'),('200202100337','364353','Pelayanan tenaga kependidikan yang sopan, ramah dan bertanggungjawab (administrasi, laboran dll)','2020-02-02 22:03:46','0000-00-00 00:00:00'),('200202100359','364353','Pelayanan tenaga kependidikan yang cepat dan tepat waktu (administrasi, laboran dll)','2020-02-02 22:04:05','0000-00-00 00:00:00'),('200202100417','364353','Prosedur pengurusan kegiatan pembelajaran  (KRS, pembimbingan dll) yang mudah dan tidak bertele - tele','2020-02-02 22:04:21','0000-00-00 00:00:00'),('200202100429','364353','Kompetensi dan kualitas dosen yang bagus, didukung dengan teaching method yang bervariasi','2020-02-02 22:04:32','0000-00-00 00:00:00'),('200202100445','364353','Pembelajaran berfokus pada mahasiswa dengan menggunakan metode pembelajaran aktif','2020-02-02 22:04:49','0000-00-00 00:00:00'),('200202100454','367453','Proses menentukan topik penelitian untuk Skripsi/Tugas Akhir','2020-02-02 22:05:03','0000-00-00 00:00:00'),('200202100505','367453','Penguasaan dosen pembimbing terhadap topik/materi penelitian mahasiswa','2020-02-02 22:05:16','0000-00-00 00:00:00'),('200202100518','367453','Ketersediaan waktu bimbingan yang diberikan oleh dosen pembimbing','2020-02-02 22:05:27','0000-00-00 00:00:00'),('200202100530','367453','Masa/jangka waktu bimbingan Skripsi/Tugas Akhir','2020-02-02 22:05:38','0000-00-00 00:00:00'),('200202100540','367453','Tingkat kesulitan materi  ujian Skripsi/Tugas Akhir','2020-02-02 22:05:48','0000-00-00 00:00:00'),('200202100605','367453','Transparansi penilaian ujian Skripsi/Tugas Akhir dari dosen pembimbing dan dosen penguji','2020-02-02 22:06:13','0000-00-00 00:00:00'),('231313','122222','Ruang pembelajaran yang bersih, nyaman dan rapi','2020-01-01 16:01:05','0000-00-00 00:00:00'),('536241','122222','Institusi mempunyai laboratorium yang relevan dengan kebutuhan keilmuan bidang di program studi ( Keperawatan, Kesehatan Masyarakat, Farmasi)','2020-01-02 00:12:36','0000-00-00 00:00:00'),('564544','122222','Institusi menyediakan sarana pembelajaran yang memadai diruang kuliah (Kipas, LCD, White board, sound, mix dll)','2020-01-02 00:12:36','0000-00-00 00:00:00');

--
-- Table structure for table `pertanyaandosen`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `pertanyaandosen` (
  `pertanyaanID` varchar(30) NOT NULL,
  `groupID` varchar(30) NOT NULL,
  `pertanyaan` varchar(300) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`pertanyaanID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pertanyaandosen`
--

INSERT INTO `pertanyaandosen` (`pertanyaanID`, `groupID`, `pertanyaan`, `created_at`, `updated_at`) VALUES ('200202101341','200202101100','Dosen menyampaikan RPS (Rencana Pembelajaran Semester)/Silabus/SAP (Satuan Acara Pembelajaran) di awal perkuliahan','2020-02-02 22:13:55','0000-00-00 00:00:00'),('200202101400','200202101100','Dosen memberikan informasi mengenai buku teks atau rujukan yang digunakan','2020-02-02 22:14:07','0000-00-00 00:00:00'),('200202101409','200202101100','Menyediakan/memberikan bahan ajar diluar buku rujukan (handout/transparan sheet/power point slide) yang cukup jelas untuk setiap materi','2020-02-02 22:14:16','0000-00-00 00:00:00'),('200202101419','200202101100','Tugas yang diberikan relevan dengan materi kuliah dan tujuan pembelajaran','2020-02-02 22:14:25','0000-00-00 00:00:00'),('200202101428','200202101212','Materi yang disampaikan sesuai dengan RP/Silabus/SAP','2020-02-02 22:14:36','0000-00-00 00:00:00'),('200202101438','200202101212','Materi kuliah disampaikan secara sistematis dan jelas','2020-02-02 22:14:45','0000-00-00 00:00:00'),('200202101447','200202101212','Dosen mendorong mahasiswa untuk aktif dikelas (contoh : bertanya, berdiskusi, berlatih)','2020-02-02 22:14:53','0000-00-00 00:00:00'),('200202101457','200202101212','Contoh dan aplikasi materi diberikan dengan jelas','2020-02-02 22:15:04','0000-00-00 00:00:00'),('200202101507','200202101212','Penggunaan berbagai media pengajaran (papan tulis, alat peraga, OHP, LCD)','2020-02-02 22:15:15','0000-00-00 00:00:00'),('200202101518','200202101212','Dosen menyampaikan materi dengan memberikan landasan nilai-nilai spiritual','2020-02-02 22:15:25','0000-00-00 00:00:00'),('200202101538','200202101212','Dosen memperlihatkan sikap dan tutur kata yang baik','2020-02-02 22:15:41','0000-00-00 00:00:00'),('200202101543','200202101243','Kuliah dilaksanakan tepat waktu','2020-02-02 22:15:52','0000-00-00 00:00:00'),('200202101554','200202101243','Dosen menggunakan beragam metode mengajar (ceramah, diskusi, mengajukan pertanyaan, memberi contoh, dll)','2020-02-02 22:16:01','0000-00-00 00:00:00'),('200202101603','200202101243','Dosen mau menerima masukan/kritikan yang memperbaiki mutu pembelajaran','2020-02-02 22:16:13','0000-00-00 00:00:00'),('200202101615','200202101243','Dosen membantu kesulitan mahasiswa dalam materi ajar','2020-02-02 22:16:24','0000-00-00 00:00:00'),('200202101626','200202101243','Dosen membuka dan menutup kelas dengan doa','2020-02-02 22:16:33','0000-00-00 00:00:00'),('200202101635','200202101314','Dosen menyampaikan tata cara penilaian dalam pembelajaran','2020-02-02 22:16:46','0000-00-00 00:00:00'),('200202101648','200202101314','Pertanyaan ujian (UTS/UAS) sesuai dengan lingkup materi yang diberikan','2020-02-02 22:16:57','0000-00-00 00:00:00'),('200202101701','200202101314','Dosen pernah membahas tugas, kuis/ujian yang telah dilaksanakan','2020-02-02 22:17:09','0000-00-00 00:00:00');

--
-- Table structure for table `products`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `products` (
  `ProductID` int(11) NOT NULL AUTO_INCREMENT,
  `ProductName` varchar(40) DEFAULT NULL,
  `SupplierID` int(11) DEFAULT NULL,
  `CategoryID` int(11) DEFAULT NULL,
  `QuantityPerUnit` varchar(20) DEFAULT NULL,
  `UnitPrice` float(1,0) DEFAULT 0,
  `UnitsInStock` smallint(6) DEFAULT 0,
  `UnitsOnOrder` smallint(6) DEFAULT 0,
  `ReorderLevel` smallint(6) DEFAULT 0,
  `Discontinued` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`ProductID`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ProductID`, `ProductName`, `SupplierID`, `CategoryID`, `QuantityPerUnit`, `UnitPrice`, `UnitsInStock`, `UnitsOnOrder`, `ReorderLevel`, `Discontinued`) VALUES (1,'Chai',1,1,'10 boxes x 20 bags',9,39,0,10,0),(2,'Chang',1,1,'24 - 12 oz bottles',9,17,40,25,0),(3,'Aniseed Syrup',1,2,'12 - 550 ml bottles',9,13,70,25,0),(4,'Chef Anton\'s Cajun Seasoning',2,2,'48 - 6 oz jars',9,53,0,0,0),(5,'Chef Anton\'s Gumbo Mix',2,2,'36 boxes',0,0,0,0,1),(6,'Grandma\'s Boysenberry Spread',3,2,'12 - 8 oz jars',9,120,0,25,0),(7,'Uncle Bob\'s Organic Dried Pears',3,7,'12 - 1 lb pkgs.',9,15,0,10,0),(8,'Northwoods Cranberry Sauce',3,2,'12 - 12 oz jars',9,6,0,0,0),(9,'Mishi Kobe Niku',4,6,'18 - 500 g pkgs.',9,29,0,0,1),(10,'Ikura',4,8,'12 - 200 ml jars',9,31,0,0,0),(11,'Queso Cabrales',5,4,'1 kg pkg.',9,22,30,30,0),(12,'Queso Manchego La Pastora',5,4,'10 - 500 g pkgs.',9,86,0,0,0),(13,'Konbu',6,8,'2 kg box',9,24,0,5,0),(14,'Tofu',6,7,'40 - 100 g pkgs.',9,35,0,0,0),(15,'Genen Shouyu',6,2,'24 - 250 ml bottles',9,39,0,5,0),(16,'Pavlova',7,3,'32 - 500 g boxes',9,29,0,10,0),(17,'Alice Mutton',7,6,'20 - 1 kg tins',0,0,0,0,1),(18,'Carnarvon Tigers',7,8,'16 kg pkg.',9,42,0,0,0),(19,'Teatime Chocolate Biscuits',8,3,'10 boxes x 12 pieces',9,25,0,5,0),(20,'Sir Rodney\'s Marmalade',8,3,'30 gift boxes',9,40,0,0,0),(21,'Sir Rodney\'s Scones',8,3,'24 pkgs. x 4 pieces',9,3,40,5,0),(22,'Gustaf\'s Kn?ckebr?d',9,5,'24 - 500 g pkgs.',9,104,0,25,0),(23,'Tunnbr?d',9,5,'12 - 250 g pkgs.',9,61,0,25,0),(24,'Guaran? Fant?stica',10,1,'12 - 355 ml cans',9,20,0,0,1),(25,'NuNuCa Nu?-Nougat-Creme',11,3,'20 - 450 g glasses',9,76,0,30,0),(26,'Gumb?r Gummib?rchen',11,3,'100 - 250 g bags',9,15,0,0,0),(27,'Schoggi Schokolade',11,3,'100 - 100 g pieces',9,49,0,30,0),(28,'R?ssle Sauerkraut',12,7,'25 - 825 g cans',9,26,0,0,1),(29,'Th?ringer Rostbratwurst',12,6,'50 bags x 30 sausgs.',0,0,0,0,1),(30,'Nord-Ost Matjeshering',13,8,'10 - 200 g glasses',9,10,0,15,0),(31,'Gorgonzola Telino',14,4,'12 - 100 g pkgs',0,0,70,20,0),(32,'Mascarpone Fabioli',14,4,'24 - 200 g pkgs.',9,9,40,25,0),(33,'Geitost',15,4,'500 g',9,112,0,20,0),(34,'Sasquatch Ale',16,1,'24 - 12 oz bottles',9,111,0,15,0),(35,'Steeleye Stout',16,1,'24 - 12 oz bottles',9,20,0,15,0),(36,'Inlagd Sill',17,8,'24 - 250 g  jars',9,112,0,20,0),(37,'Gravad lax',17,8,'12 - 500 g pkgs.',9,11,50,25,0),(38,'C?te de Blaye',18,1,'12 - 75 cl bottles',9,17,0,15,0),(39,'Chartreuse verte',18,1,'750 cc per bottle',9,69,0,5,0),(40,'Boston Crab Meat',19,8,'24 - 4 oz tins',9,123,0,30,0),(41,'Jack\'s New England Clam Chowder',19,8,'12 - 12 oz cans',9,85,0,10,0),(42,'Singaporean Hokkien Fried Mee',20,5,'32 - 1 kg pkgs.',9,26,0,0,1),(43,'Ipoh Coffee',20,1,'16 - 500 g tins',9,17,10,25,0),(44,'Gula Malacca',20,2,'20 - 2 kg bags',9,27,0,15,0),(45,'R?gede sild',21,8,'1k pkg.',9,5,70,15,0),(46,'Spegesild',21,8,'4 - 450 g glasses',9,95,0,0,0),(47,'Zaanse koeken',22,3,'10 - 4 oz boxes',9,36,0,0,0),(48,'Chocolade',22,3,'10 pkgs.',9,15,70,25,0),(49,'Maxilaku',23,3,'24 - 50 g pkgs.',9,10,60,15,0),(50,'Valkoinen suklaa',23,3,'12 - 100 g bars',9,65,0,30,0),(51,'Manjimup Dried Apples',24,7,'50 - 300 g pkgs.',9,20,0,10,0),(52,'Filo Mix',24,5,'16 - 2 kg boxes',9,38,0,25,0),(53,'Perth Pasties',24,6,'48 pieces',0,0,0,0,1),(54,'Tourti?re',25,6,'16 pies',9,21,0,10,0),(55,'P?t? chinois',25,6,'24 boxes x 2 pies',9,115,0,20,0),(56,'Gnocchi di nonna Alice',26,5,'24 - 250 g pkgs.',9,21,10,30,0),(57,'Ravioli Angelo',26,5,'24 - 250 g pkgs.',9,36,0,20,0),(58,'Escargots de Bourgogne',27,8,'24 pieces',9,62,0,20,0),(59,'Raclette Courdavault',28,4,'5 kg pkg.',9,79,0,0,0),(60,'Camembert Pierrot',28,4,'15 - 300 g rounds',9,19,0,0,0),(61,'Sirop d\'?rable',29,2,'24 - 500 ml bottles',9,113,0,25,0),(62,'Tarte au sucre',29,3,'48 pies',9,17,0,0,0),(63,'Vegie-spread',7,2,'15 - 625 g jars',9,24,0,5,0),(64,'Wimmers gute Semmelkn?del',12,5,'20 bags x 4 pieces',9,22,80,30,0),(65,'Louisiana Fiery Hot Pepper Sauce',2,2,'32 - 8 oz bottles',9,76,0,0,0),(66,'Louisiana Hot Spiced Okra',2,2,'24 - 8 oz jars',9,4,100,20,0),(67,'Laughing Lumberjack Lager',16,1,'24 - 12 oz bottles',9,52,0,10,0),(68,'Scottish Longbreads',8,3,'10 boxes x 8 pieces',9,6,10,15,0),(69,'Gudbrandsdalsost',15,4,'10 kg pkg.',9,26,0,15,0),(70,'Outback Lager',7,1,'24 - 355 ml bottles',9,15,10,30,0),(71,'Fl?temysost',15,4,'10 - 500 g pkgs.',9,26,0,0,0),(72,'Mozzarella di Giovanni',14,4,'24 - 200 g pkgs.',9,14,0,0,0),(73,'R?d Kaviar',17,8,'24 - 150 g jars',9,101,0,5,0),(74,'Longlife Tofu',4,7,'5 kg pkg.',9,4,20,5,0),(75,'Rh?nbr?u Klosterbier',12,1,'24 - 0.5 l bottles',9,125,0,25,0),(76,'Lakkalik??ri',23,1,'500 ml',9,57,0,20,0),(77,'Original Frankfurter gr?ne So?e',12,2,'12 boxes',9,32,0,15,0),(78,'Mie Sedap Dobel',15,3,'10 boxes x 20 bags',8,1000,1,5,10),(79,'Pepsodent',4,8,'100 ml',6,12,12,10,10);

--
-- Table structure for table `programstudi`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `programstudi` (
  `prodiID` varchar(30) NOT NULL,
  `nama_prodi` varchar(50) NOT NULL,
  `jenjang` enum('D3','S1','S2','S3','Profesi') NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `status` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`prodiID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programstudi`
--

INSERT INTO `programstudi` (`prodiID`, `nama_prodi`, `jenjang`, `user_id`, `created_at`, `updated_at`, `status`) VALUES ('13201','Kesehatan Masyarakat','S1',1,'2015-09-06 10:08:02','2020-01-01 00:33:14',0x01),('14001','Ilmu Keperawatan','S1',1,'2015-09-06 10:08:22','2015-09-06 10:08:28',0x01),('14901','Profesi Ners','Profesi',1,'2015-09-06 09:57:19','2015-09-22 21:36:34',0x01),('48401','Farmasi','D3',1,'2015-09-06 10:05:02','2018-04-11 20:51:54',0x01);

--
-- Table structure for table `suppliers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `suppliers` (
  `SupplierID` int(11) NOT NULL AUTO_INCREMENT,
  `CompanyName` varchar(40) DEFAULT NULL,
  `ContactName` varchar(30) DEFAULT NULL,
  `ContactTitle` varchar(30) DEFAULT NULL,
  `Address` varchar(60) DEFAULT NULL,
  `City` varchar(15) DEFAULT NULL,
  `Region` varchar(15) DEFAULT NULL,
  `PostalCode` varchar(10) DEFAULT NULL,
  `Country` varchar(15) DEFAULT NULL,
  `Phone` varchar(24) DEFAULT NULL,
  `Fax` varchar(24) DEFAULT NULL,
  `HomePage` text DEFAULT NULL,
  PRIMARY KEY (`SupplierID`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`SupplierID`, `CompanyName`, `ContactName`, `ContactTitle`, `Address`, `City`, `Region`, `PostalCode`, `Country`, `Phone`, `Fax`, `HomePage`) VALUES (1,'Exotic Liquids','Charlotte Cooper','Purchasing Manager','49 Gilbert St.','London','London','EC1 4SD','United Kingdom','(171) 555-2222','085647541087','https://exotic-liquids.com'),(2,'New Orleans Cajun Delights','Shelley Burke','Order Administrator','P.O. Box 78934','New Orleans','LA','70117','United States','(100) 555-4822','','#CAJUN.HTM#'),(3,'Grandma Kelly\'s Homestead','Regina Murphy','Sales Representative','707 Oxford Rd.','Ann Arbor','MI','48104','United States','(313) 555-5735','(313) 555-3349',''),(4,'Tokyo Traders','Yoshi Nagase','Marketing Manager','9-8 Sekimai\r\nMUnited Statesshino-shi','Tokyo','','100','Japan','(03) 3555-5011','',''),(5,'Cooperativa de Quesos \'Las Cabras\'','Antonio del Valle Saavedra','Export Administrator','Calle del Rosal 4','Oviedo','Asturias','33007','Spain','(98) 598 76 54','',''),(6,'Mayumi\'s','Mayumi Ohno','Marketing Representative','92 Setsuko\r\nChuo-ku','Osaka','','545','Japan','(06) 431-7877','','Mayumi\'s (on the World Wide Web)#http://www.microsoft.com/accessdev/sampleapps/mayumi.htm#'),(7,'Pavlova, Ltd.','Ian Devling','Marketing Manager','74 Rose St.\r\nMoonie Ponds','Melbourne','Victoria','3058','Australia','(03) 444-2343','(03) 444-6588',''),(8,'Specialty Biscuits, Ltd.','Peter Wilson','Sales Representative','29 King\'s Way','Manchester','','M14 GSD','United Kingdom','(161) 555-4448','',''),(9,'PB Kn?ckebr?d AB','Lars Peterson','Sales Agent','Kaloadagatan 13','G?teborg','','S-345 67','Sweden','031-987 65 43','031-987 65 91',''),(10,'Refrescos Americanas LTDA','Carlos Diaz','Marketing Manager','Av. das Americanas 12.890','S?o Paulo','','5442','Brazil','(11) 555 4640','',''),(11,'Heli S??waren GmbH & Co. KG','Petra Winkler','Sales Manager','Tiergartenstra?e 5','Berlin','','10785','Germany','(010) 9984510','',''),(12,'Plutzer Lebensmittelgro?m?rkte AG','Martin Bein','International Marketing Mgr.','Bogenallee 51','Frankfurt','','60439','Germany','(069) 992755','','Plutzer (on the World Wide Web)#http://www.microsoft.com/accessdev/sampleapps/plutzer.htm#'),(13,'Nord-Ost-Fisch Handelsgesellschaft mbH','Sven Petersen','Coordinator Foreign Markets','Frahmredder 112a','Cuxhaven','','27478','Germany','(04721) 8713','(04721) 8714',''),(14,'Formaggi Fortini s.r.l.','Elio Rossi','Sales Representative','Viale Dante, 75','Ravenna','','48100','Italy','(0544) 60323','(0544) 60603','#FORMAGGI.HTM#'),(15,'Norske Meierier','Beate Vileid','Marketing Manager','Hatlevegen 5','Sandvika','','1320','Norway','(0)2-953010','',''),(16,'Bigfoot Breweries','Cheryl Saylor','Regional Account Rep.','3400 - 8th Avenue\r\nSuite 210','Bend','OR','97101','United States','(503) 555-9931','',''),(17,'Svensk Sj?f?da AB','Michael Bj?rn','Sales Representative','Brovallav?gen 231','Stockholm','','S-123 45','Sweden','08-123 45 67','',''),(18,'Aux joyeux eccl?siastiques','Guyl?ne Nodier','Sales Manager','203, Rue des Francs-Bourgeois','Paris','','75004','France','(1) 03.83.00.68','(1) 03.83.00.62',''),(19,'New England Seafood Cannery','Robb Merchant','Wholesale Account Agent','Order Processing Dept.\r\n2100 Paul Revere Blvd.','Boston','MA','02134','United States','(617) 555-3267','(617) 555-3389',''),(20,'Leka Trading','Chandra Leka','Owner','471 Serangoon Loop, Suite #402','Singapore','Singapore','0512','Singapore','555-8787','',''),(21,'Lyngbysild','Niels Petersen','Sales Manager','Lyngbysild\r\nFiskebakken 10','Lyngby','','2800','Denmark','43844108','43844115',''),(22,'Zaanse Snoepfabriek','Dirk Luchte','Accounting Manager','Verkoop\r\nRijnweg 22','Zaandam','','9999 ZZ','Netherlands','(12345) 1212','(12345) 1210',''),(23,'Karkki Oy','Anne Heikkonen','Product Manager','Valtakatu 12','Lappeenranta','','53120','Finland','(953) 10956','',''),(24,'G\'day, Mate','Wendy Mackenzie','Sales Representative','170 Prince Edward Parade\r\nHunter\'s Hill','Sydney','NSW','2042','Australia','(02) 555-5914','(02) 555-4873','G\'day Mate (on the World Wide Web)#http://www.microsoft.com/accessdev/sampleapps/gdaymate.htm#'),(25,'Ma Maison','Jean-Guy Lauzon','Marketing Manager','2960 Rue St. Laurent','Montr?al','Qu?bec','H1J 1C3','Canada','(514) 555-9022','',''),(26,'Pasta Buttini s.r.l.','Giovanni Giudici','Order Administrator','Via dei Gelsomini, 153','Salerno','','84100','Italy','(089) 6547665','(089) 6547667',''),(27,'Escargots Nouveaux','Marie Delamare','Sales Manager','22, rue H. Voiron','Montceau','','71300','France','85.57.00.07','',''),(28,'Gai p?turage','Eliane Noz','Sales Representative','Bat. B\r\n3, rue des Alpes','Annecy','','74000','France','38.76.98.06','38.76.98.58',''),(29,'For?ts d\'?rables','Chantal Goulet','Accounting Manager','148 rue Chasseur','Ste-Hyacinthe','Qu?bec','J2S 7S8','Canada','(514) 555-2955','(514) 555-2921','');

--
-- Table structure for table `tahunakademik`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `tahunakademik` (
  `thnAkademikID` varchar(30) NOT NULL,
  `thnAkademik` varchar(30) NOT NULL,
  `status` enum('Aktif','Tidak Aktif') NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`thnAkademikID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tahunakademik`
--

INSERT INTO `tahunakademik` (`thnAkademikID`, `thnAkademik`, `status`, `created_at`, `updated_at`) VALUES ('213123','2018/2019','Tidak Aktif','2019-12-14 00:00:00','2020-02-27 07:31:07'),('237467','2017/2018','Tidak Aktif','2019-12-28 14:03:13','2020-02-27 07:31:07'),('544587','2019/2020','Aktif','2019-12-14 00:00:00','2020-02-27 07:31:07'),('784672','2016/2017','Tidak Aktif','2019-12-28 14:03:13','2020-02-27 07:31:07');

--
-- Table structure for table `users`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(254) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `last_login` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES (1,'127.0.0.1','administrator','$2a$07$SeBknntpZror9uyftVopmu61qg0ms8Qv1yV6FG.kQOSM.9QhmTo36','','admin@admin.com','',NULL,NULL,'H07GdYUUfWXFBOvyjSJose','2020-02-27 19:35:15','2020-02-27 13:35:15',1,'Admin','istrator','ADMIN','0');

--
-- Table structure for table `users_groups`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `users_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  KEY `fk_users_groups_users1_idx` (`user_id`),
  KEY `fk_users_groups_groups1_idx` (`group_id`),
  CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES (1,1,1),(2,1,2);
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-02 18:00:13
